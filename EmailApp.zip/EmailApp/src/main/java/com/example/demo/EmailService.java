package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("emailService")
public class EmailService {

    DataSource obj1=null;

    @Autowired
    public EmailService(DataSource t) {
        this.obj1=t;
//        System.out.println("constructor inject Bean " +this.obj1);
    }

    public void sendEmail() {
        obj1.returnConnection();
    }
}