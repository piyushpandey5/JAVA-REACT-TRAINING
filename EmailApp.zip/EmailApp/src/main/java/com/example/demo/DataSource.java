package com.example.demo;

public interface DataSource {

	void returnConnection();

}
