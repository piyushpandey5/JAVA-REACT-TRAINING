package com.example.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("postgeSqlDataSource")
public class PostgeSqlDataSource implements DataSource{
	@Override
    public void returnConnection() {
        System.out.println("PostgreSQL Connected");
    }

}
