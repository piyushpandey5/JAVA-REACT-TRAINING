package com.example.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("mySqlDataSource")
@Primary
public class MySqlDataSource implements DataSource{
	@Override
    public void returnConnection() {
        System.out.println("MySqlDataSource Connected");
    }

}
