package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("traveller")
public class Traveller {
	private Vehicle obj = null;
//	@Autowired
//	public Traveller(@Qualifier("cycle")Vehicle t) {
//		super();
//		this.obj = t;
//	}
	
	// ***below code is to check primary***
	@Autowired
	public Traveller(Vehicle t) {
		super();
		this.obj = t;
	}
	public void startJourney() {
		this.obj.move();
	}
}
