package com.example.demo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Client {
	
	public static void main(String[] args) {
//		Vehicle t = new Cycle();
//		Traveller obj = new Traveller(t);
//		obj.startJourney();
		
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
//		Car obj = applicationContext.getBean(Car.class);
//		obj.move();
		Traveller obj1 = applicationContext.getBean(Traveller.class);
		obj1.startJourney();
	}
	
}
