package entity;

import java.util.List;
import java.util.Objects;

public class Bank {
	private String name;
	private List<BankAccount> accountList;
	public Bank() {
		super();
	}
	public Bank(String name, List<BankAccount> accountList) {
		super();
		this.name = name;
		this.accountList = accountList;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<BankAccount> getAccountList() {
		return accountList;
	}
	public void setAccountList(List<BankAccount> accountList) {
		this.accountList = accountList;
	}
	@Override
	public String toString() {
		return "Bank [name=" + name + ", accountList=" + accountList + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(accountList, name);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bank other = (Bank) obj;
		return Objects.equals(accountList, other.accountList) && Objects.equals(name, other.name);
	}
	

}
