package main;
import java.util.ArrayList;
import java.util.logging.Logger;
import dao.ServiceProviderImpl;
import entity.Bank;
import entity.BankAccount;
import com.exception.AccountNumberInvalidException;
import com.exception.InsufficientFundsException;
import com.exception.NegativeAmountException;

public class MainMod {
    private static final Logger LOGGER = Logger.getLogger(MainMod.class.getName());

    public static void main(String[] args) throws InsufficientFundsException, AccountNumberInvalidException,
            NegativeAmountException {

        // TODO Auto-generated method stub
        BankAccount obj1 = new BankAccount("Narendra", "Current", 80000.50);
        BankAccount obj2 = new BankAccount("Gajendra", "Savings", 20000.50);
        BankAccount obj3 = new BankAccount("Virendra", "Current", 35000.50);

        ArrayList<BankAccount> myList = new ArrayList<>();
        myList.add(obj1);
        myList.add(obj2);
        myList.add(obj3);

        Bank myBank = new Bank("ICICI", myList);

        ServiceProviderImpl myServiceObj = new ServiceProviderImpl(myBank);

        // Logging the starting point of the program
        LOGGER.info("Starting the MainMod program.");

        try {
            int accountNumber = 1111;
            // Logging the balance check for accountNumber
            LOGGER.info("Checking balance for account: " + accountNumber);
            System.out.println("Balance of account " + accountNumber + " : " + myServiceObj.checkBalance(accountNumber));
            
            // Logging the deposit operation
            LOGGER.info("Depositing -5000.50 to account: " + accountNumber);
            System.out.println("Status of deposit: " + myServiceObj.deposit(accountNumber, -5000.50));

            // Logging the balance check after deposit
            LOGGER.info("Checking balance for account: " + accountNumber);
            System.out.println("Balance of account " + accountNumber + " : " + myServiceObj.checkBalance(accountNumber));
        } catch (NegativeAmountException e) {
            // Logging negative amount exception
            LOGGER.warning("NegativeAmountException: " + e.getMessage());
            throw new NegativeAmountException("Balance cannot be negative");
        } catch (AccountNumberInvalidException e) {
            // Logging account number invalid exception
            LOGGER.warning("AccountNumberInvalidException: " + e.getMessage());
            throw new AccountNumberInvalidException("Account number is invalid");
        } finally {
            // Logging the final state of the bank
            LOGGER.info("Final state of the bank: " + myBank);
        }

        // Logging the end of the program
        LOGGER.info("MainMod program completed.");
    }
}