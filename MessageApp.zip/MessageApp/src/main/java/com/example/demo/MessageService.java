package com.example.demo;

public interface MessageService {
	void sendMessage(String message);
}
