package com.example.demo;

import org.springframework.stereotype.Component;

@Component("smsService")
class SMSService implements MessageService {
    @Override
    public void sendMessage(String message) {
    System.out.println("Sending sms: " + message);
    }
}
