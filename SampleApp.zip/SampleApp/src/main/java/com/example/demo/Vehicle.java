package com.example.demo;

interface Vehicle {
    // Method to move
    public void move();

}
