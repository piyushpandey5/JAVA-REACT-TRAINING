package com.example.demo;
import org.springframework.context.ApplicationContext; //interface for Spring IoC container
import org.springframework.context.annotation.AnnotationConfigApplicationContext; //specific implementation of it that is configured using Java annotations

public class Client {
	
	public static void main(String[] args) {
//		Vehicle t = new Cycle();
//		Traveller obj = new Traveller(t);
//		obj.startJourney();
		
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
		Cycle obj = applicationContext.getBean(Cycle.class);
		obj.move();
	}
	
}
