package com.example.demo;

public class Traveller {
	private Vehicle obj = null;
	
	public Traveller(Vehicle t) {
		super();
		this.obj = t;
	}
	public void startJourney() {
		this.obj.move();
	}
}
