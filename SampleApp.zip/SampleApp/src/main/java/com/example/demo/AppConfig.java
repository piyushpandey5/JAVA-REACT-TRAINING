package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean
	public Vehicle ReturnCar() {
		return new Car();
	}
	@Bean
	public Vehicle ReturnBike() {
		return new Bike();
	}
	@Bean
	public Vehicle ReturnCycle() {
		return new Cycle();
	}
	@Bean
	public Traveller ReturnTraveller() {
		return new Traveller(ReturnBike());
	}

}
